package runner;

import org.testng.annotations.DataProvider;

import base.BaseClass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@CucumberOptions(features = "src/main/java/features",
					glue = {"pages"},
					monochrome = true,
					publish = true,
					dryRun = false,
					snippets = SnippetType.CAMELCASE,
//					tags = "@Smoke" // include all scenarios with the specific tag
//					tags = "@Smoke or @Sanity" //  include scenarios with either one of the tags
//					tags = "@Regression and @Sanity" // include scenarios which has all tags
					tags = "not @Regression") // exclude all other scenarios
public class Runner extends BaseClass{

	@DataProvider(parallel = true)
    public Object[][] scenarios() {
		return super.scenarios();
	}
}
