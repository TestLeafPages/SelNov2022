package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;
import io.cucumber.java.en.Given;

public class LoginPage extends BaseClass{
	
//	public LoginPage(RemoteWebDriver driver) {
//		this.driver = driver;
//	}
	
	@Given("Enter the Username as (.*)$")
	public LoginPage enterUserName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		return this;
	}
	
	@Given("Enter the Password as (.*)$")
	public LoginPage enterPassword(String pwd) {
		driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	
	@Given("Click on the Login button")
	public HomePage clickLogin() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage(driver);
	}

}
