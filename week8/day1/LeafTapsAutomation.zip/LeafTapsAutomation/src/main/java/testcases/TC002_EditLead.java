package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;
import pages.MyHomePage;

public class TC002_EditLead extends BaseClass{

	@BeforeClass
	public void setData() {
		fileName = "CreateLead";
	}
	
	@Test(dataProvider = "fetchData")
	public void runEditLead(String uName, String pwd) {
		new LoginPage(driver)
		.enterUserName(uName)
		.enterPassword(pwd) 
		.clickLogin()	// new HomePage()
		.clickCRMSFA() // new MyHomePage()
		.clickLeads()	// new LeadsPage()
		.clickFindLeads();
	}
}
