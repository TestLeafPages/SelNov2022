package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class LeadsPage extends BaseClass{

	public LeadsPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	public void clickCreateLead() {
		
	}
	
	public void clickFindLeads() {
		
	}
}
