package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class CreateLeadPage extends BaseClass {

//	public CreateLeadPage(RemoteWebDriver driver) {
//		this.driver = driver;
//	}

	
	public CreateLeadPage enterCompanyName() {
		
		return this;
	}

	public void enterFirstName() {

	}

	public void enterLastName() {

	}

	public void clickCreateLead() {

	}
}
