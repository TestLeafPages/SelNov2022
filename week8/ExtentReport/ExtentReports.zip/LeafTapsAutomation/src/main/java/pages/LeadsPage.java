package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class LeadsPage extends BaseClass{

	public LeadsPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	public void clickCreateLead() {
		driver.findElement(By.linkText(prop2.getProperty("link_create_lead"))).click();
	}
	
	public void clickFindLeads() {
		
	}
}
