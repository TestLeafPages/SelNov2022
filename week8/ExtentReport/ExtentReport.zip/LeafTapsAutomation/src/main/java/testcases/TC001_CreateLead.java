package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.HomePage;
import pages.LoginPage;
import pages.MyHomePage;

public class TC001_CreateLead extends BaseClass{
	
	@BeforeTest
	public void setData() {
		fileName = "CreateLead";
		testName = "CreateLead";
		testDesc = "Create Lead with Mandatory fields";
		testCategory = "Smoke";
		testAuthor = "Haja";
	}

	@Test(dataProvider = "fetchData")
	public void runCreateLead(String uName, String pwd) {
//		LoginPage lp = new LoginPage();
//		lp.enterUserName();
//		lp.enterPassword();
//		lp.clickLogin();
//		
//		HomePage hp = new HomePage();
//		hp.clickCRMSFA();
//		
//		MyHomePage mhp = new MyHomePage();
//		mhp.clickLeads();
		
		new LoginPage(driver)
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()	// new HomePage()
		.clickCRMSFA() // new MyHomePage()
		.clickLeads()	// new LeadsPage()
		.clickCreateLead();
	}
}
