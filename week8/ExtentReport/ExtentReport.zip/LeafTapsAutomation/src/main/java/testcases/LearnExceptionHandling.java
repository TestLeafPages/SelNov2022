package testcases;

public class LearnExceptionHandling {

	public static void main(String[] args) {
		
		int x = 10;
		int y = 1;
		
		int[] z = {1, 12, 13};
		
		try {
			System.out.println(x/y);
		} catch (ArithmeticException e) {
			if(y==0) {
				System.out.println(x/1);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		try {
			System.out.println(z[2]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Index is not present in the array");
		} finally {
			System.out.println("Finally block");
		}
		
		System.out.println("End of line");
	}

}
