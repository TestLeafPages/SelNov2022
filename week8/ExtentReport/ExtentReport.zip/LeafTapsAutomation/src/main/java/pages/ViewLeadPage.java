package pages;

import org.openqa.selenium.remote.RemoteWebDriver;

import base.BaseClass;

public class ViewLeadPage extends BaseClass{

	public ViewLeadPage(RemoteWebDriver driver) {
		this.driver = driver;
	}
	
	public void verifyFirstName() {
		
	}
	
	public void clickEdit() {
		
	}
}
